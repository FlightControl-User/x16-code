// Space flight engine for a space game written in kickc for the Commander X16.

#pragma link("equinoxe.ld")
#pragma encoding(petscii_mixed)
#pragma var_model(mem, local_mem)

// #pragma zp_reserve(0x00..0x21, 0x80..0x9C, 0xFC..0xFF)

#include <lib_conio_asm.h>

#include "equinoxe.h"
#include "equinoxe-layers_asm.h"
#include "equinoxe-animate_asm.h"
#include "equinoxe-palette_asm.h"
#include "equinoxe-flightengine_asm.h"
#include <lib_lru_cache_asm.h>
#include <lib_bramheap_asm.h>
#include <lib_veraheap_asm.h>
#include <lib_conio_asm.h>

#include "equinoxe-levels.h"

#pragma data_seg(Debug)
// volatile char buffer[256];

#pragma data_seg(Data)
#pragma nobank
#pragma var_model(mem)

equinoxe_game_t game = {1, 0, 0, 0, 0, 127, 64, 1, 
                        0x02, 0x0A, 0x0f, 0x0f, 1, -1 };
// __mem FILE* music;
// unsigned char music_buffer[1024];

volatile sprite_index_t sprite_offset;

void equinoxe_init() {

    // Load all banks with data and code!
    unsigned bytes = 0;
    bytes = fload_bram("stages.bin", BANK_ENGINE_STAGES, (bram_ptr_t)0xA000);
    bytes = fload_bram("bramflight1.bin", BANK_ENGINE_SPRITES, (bram_ptr_t)0xA000);
    bytes = fload_bram("bramfloor1.bin", BANK_ENGINE_FLOOR, (bram_ptr_t)0xA000);
    bytes = fload_bram("veraheap.bin", BANK_VERA_HEAP, (bram_ptr_t)0xA000);

    flight_init();

#ifdef __PLAYER
    bytes = fload_bram("players.bin", BANK_ENGINE_PLAYERS, (bram_ptr_t)0xA000);
#endif


    animate_init();

    // Initialize the cache in vram for the sprite animations.
    lru_cache_init();
}




//VSYNC Interrupt Routine

#ifndef __NOVSYNC
__interrupt(rom_sys_cx16) void irq_vsync() {
#else
void irq_vsync() {
#endif

    bank_set_brom(0);

    // asm {.byte $db}

    #ifdef __CPULINES
        vera_display_set_border_color(YELLOW);
    #endif

    // unsigned int read = fgets(music_buffer, 512, music);

#ifdef __FLOOR

    #ifdef __LAYER1
    vera_floor_layer1();
    #endif

    vera_floor_layer0();
#endif

    // This is essential, the BRAM bank is set to 0, because the sprite control blocks are located between address A8000 till BFFF.
    bank_push_set_bram(255);


    #ifdef __CPULINES
        vera_display_set_border_color(BLUE);
    #endif

    // cx16_mouse_scan(); 
    cx16_mouse_get();

    #ifdef __PLAYER
        #ifdef __CPULINES
            vera_display_set_border_color(LIGHT_BLUE);
        #endif
        player_logic();
    #endif

    // BREAKPOINT
    vera_display_set_border_color(GREY);
    flight_draw();

#ifndef __NOVSYNC
    // Reset the VSYNC interrupt
    *VERA_ISR = 1;
#endif

    bank_pull_bram();

    #ifdef __CPULINES
        vera_display_set_border_color(BLACK);
    #endif
}



/// @brief game startup
void main() {

    // cx16_brk_debug();

#ifdef __CPULINES
    // Set border to measure scan lines
    vera_display_set_hstart(1);
    vera_display_set_hstop(159);
    vera_display_set_vstart(0);
    vera_display_set_vstop(238);
    vera_display_set_border_color(RED);
#endif


    // We are going to use only the kernal on the X16.
    bank_set_brom(CX16_ROM_KERNAL);

    vera_floor_layer0_hide();
    vera_floor_layer1_hide();

#ifndef __LAYER1
    vera_petscii_init();
#else
    game.layers++; // This to indicate that two layers are to be drawn in the floor engine!
#endif
    scroll(1);

    #ifndef __LAYER1
    textcolor(WHITE);
    bgcolor(BLACK);
    clrscr();
    #endif

    // music = fopen("music.bin","r");

    equinoxe_init();

    // We initialize the Commander X16 BRAM heap manager. This manages dynamically the memory space in banked ram as a real heap.
    bram_heap_bram_bank_init(BANK_HEAP_BRAM);
    // BREAKPOINT
    bram_heap_segment_init(0, 0x10, (bram_ptr_t)0xA000, 0x3C, (bram_ptr_t)0xA000);

    bram_heap_segment_init(1, 0x3C, (bram_ptr_t)0xA000, 0x3F, (bram_ptr_t)0xA000);

    // We intialize the Commander X16 VERA heap manager. This manages dynamically the memory space in vera ram as a real heap.
    vera_heap_bram_bank_init(BANK_VERA_HEAP);
    vera_heap_segment_init(VERA_HEAP_SEGMENT_TILES, FLOOR_TILE_BANK_VRAM, FLOOR_TILE_OFFSET_VRAM, SPRITE_BANK_VRAM, SPRITE_OFFSET_VRAM); // FLOOR_TILE segment for tiles of various sizes and types
    vera_heap_segment_init(VERA_HEAP_SEGMENT_SPRITES, SPRITE_BANK_VRAM, SPRITE_OFFSET_VRAM, FLOOR_MAP1_BANK_VRAM, FLOOR_MAP1_OFFSET_VRAM); // SPRITES segment for sprites of various sizes


#ifdef __FLOOR

    vera_floor_layer0();

    #ifdef __LAYER1
    vera_floor_layer1();
    #else
    vera_petscii_layer1();
    #endif

#endif

    palette_init(BANK_ENGINE_PALETTE);

    load_player(&stage_player);
    player_add(1,2);

    scroll(0);

    vera_display_set_border_color(BLACK);

    cbm_k_clrchn();
    while(!kbhit());

#ifndef __NOVSYNC
    // Enable VSYNC IRQ (also set line bit 8 to 0)
    SEI();
    cx16_irq_relay(&irq_vsync);
    // *KERNEL_IRQ = &irq_vsync;
    *VERA_IEN = VERA_VSYNC | 0x80;
    *VERA_IRQLINE_L = 0xFF;
    CLI();
#endif

    cx16_mouse_config(0xFF, 80, 60);
    cx16_mouse_get();

    vera_sprites_show();

    volatile unsigned char ch = kbhit();
    while (ch != 'x') {
        #ifdef __NOVSYNC
            irq_vsync();
        #endif

        #ifdef __NOVSYNC
        SEI();
        #endif
        ch=kbhit();
        #ifdef __NOVSYNC
        CLI();
        #endif
    }; 

    // Back to basic.
    bank_set_brom(CX16_ROM_BASIC);
}

